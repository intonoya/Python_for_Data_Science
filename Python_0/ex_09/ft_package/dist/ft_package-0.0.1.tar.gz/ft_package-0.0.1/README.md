# ft_package

A sample test package to demonstrate package creation.

## Installation

```bash
pip install ./dist/ft_package-0.0.1.tar.gz
# or
pip install ./dist/ft_package-0.0.1-py3-none-any.whl
